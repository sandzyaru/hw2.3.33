package com.example.hw233;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private EditText email,subject,message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=findViewById(R.id.send);
        email=findViewById(R.id.email_text);
        subject=findViewById(R.id.subject_text);
        message=findViewById(R.id.message_text);
        String [] recipients={email.getText().toString()};
        button.setOnClickListener(view -> {

            Intent emailIntent = new Intent(Intent.ACTION_SEND);
            emailIntent.putExtra(Intent.EXTRA_EMAIL,email.getText().toString());
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject.getText().toString());
            emailIntent.putExtra(Intent.EXTRA_TEXT, message.getText().toString());
            emailIntent.setType("text/html");
            emailIntent.setPackage("com.google.android.gm");
            startActivity(emailIntent);
        });
    }
}